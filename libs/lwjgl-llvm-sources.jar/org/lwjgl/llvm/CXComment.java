/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.llvm;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * <pre>{@code
 * struct CXComment {
 *     void const * ASTNode;
 *     CXTranslationUnit TranslationUnit;
 * }}</pre>
 */
public class CXComment extends Struct<CXComment> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        ASTNODE,
        TRANSLATIONUNIT;

    static {
        Layout layout = __struct(
            __member(POINTER_SIZE),
            __member(POINTER_SIZE)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        ASTNODE = layout.offsetof(0);
        TRANSLATIONUNIT = layout.offsetof(1);
    }

    protected CXComment(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected CXComment create(long address, @Nullable ByteBuffer container) {
        return new CXComment(address, container);
    }

    /**
     * Creates a {@code CXComment} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public CXComment(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return the value of the {@code ASTNode} field. */
    @NativeType("void const *")
    public long ASTNode() { return nASTNode(address()); }
    /** @return the value of the {@code TranslationUnit} field. */
    @NativeType("CXTranslationUnit")
    public long TranslationUnit() { return nTranslationUnit(address()); }

    // -----------------------------------

    /** Returns a new {@code CXComment} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static CXComment malloc() {
        return new CXComment(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code CXComment} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static CXComment calloc() {
        return new CXComment(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code CXComment} instance allocated with {@link BufferUtils}. */
    public static CXComment create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new CXComment(memAddress(container), container);
    }

    /** Returns a new {@code CXComment} instance for the specified memory address. */
    public static CXComment create(long address) {
        return new CXComment(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable CXComment createSafe(long address) {
        return address == NULL ? null : new CXComment(address, null);
    }

    /**
     * Returns a new {@link CXComment.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static CXComment.Buffer malloc(int capacity) {
        return new Buffer(nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link CXComment.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static CXComment.Buffer calloc(int capacity) {
        return new Buffer(nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link CXComment.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static CXComment.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return new Buffer(memAddress(container), container, -1, 0, capacity, capacity);
    }

    /**
     * Create a {@link CXComment.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static CXComment.Buffer create(long address, int capacity) {
        return new Buffer(address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static CXComment.@Nullable Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : new Buffer(address, capacity);
    }

    /**
     * Returns a new {@code CXComment} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static CXComment malloc(MemoryStack stack) {
        return new CXComment(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code CXComment} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static CXComment calloc(MemoryStack stack) {
        return new CXComment(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    /**
     * Returns a new {@link CXComment.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static CXComment.Buffer malloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link CXComment.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static CXComment.Buffer calloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #ASTNode}. */
    public static long nASTNode(long struct) { return memGetAddress(struct + CXComment.ASTNODE); }
    /** Unsafe version of {@link #TranslationUnit}. */
    public static long nTranslationUnit(long struct) { return memGetAddress(struct + CXComment.TRANSLATIONUNIT); }

    // -----------------------------------

    /** An array of {@link CXComment} structs. */
    public static class Buffer extends StructBuffer<CXComment, Buffer> implements NativeResource {

        private static final CXComment ELEMENT_FACTORY = CXComment.create(-1L);

        /**
         * Creates a new {@code CXComment.Buffer} instance backed by the specified container.
         *
         * <p>Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link CXComment#SIZEOF}, and its mark will be undefined.</p>
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected Buffer create(long address, @Nullable ByteBuffer container, int mark, int position, int limit, int capacity) {
            return new Buffer(address, container, mark, position, limit, capacity);
        }

        @Override
        protected CXComment getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** @return the value of the {@code ASTNode} field. */
        @NativeType("void const *")
        public long ASTNode() { return CXComment.nASTNode(address()); }
        /** @return the value of the {@code TranslationUnit} field. */
        @NativeType("CXTranslationUnit")
        public long TranslationUnit() { return CXComment.nTranslationUnit(address()); }

    }

}