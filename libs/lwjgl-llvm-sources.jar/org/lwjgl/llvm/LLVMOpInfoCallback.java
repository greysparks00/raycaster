/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.llvm;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke (* anonymous)} */
public abstract class LLVMOpInfoCallback extends Callback implements LLVMOpInfoCallbackI {

    /**
     * Creates a {@code LLVMOpInfoCallback} instance from the specified function pointer.
     *
     * @return the new {@code LLVMOpInfoCallback}
     */
    public static LLVMOpInfoCallback create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable LLVMOpInfoCallback createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code LLVMOpInfoCallback} instance that delegates to the specified {@code LLVMOpInfoCallbackI} instance. */
    public static LLVMOpInfoCallback create(LLVMOpInfoCallbackI instance) { return create(instance, instance.address()); }

    private static LLVMOpInfoCallback create(LLVMOpInfoCallbackI instance, long functionPointer) {
        return instance instanceof LLVMOpInfoCallback
            ? (LLVMOpInfoCallback)instance
            : new LLVMOpInfoCallback(functionPointer) {
                @Override public int invoke(long DisInfo, long PC, long Offset, long OpSize, long InstSize, int TagType, long TagBuf) {
                    return instance.invoke(DisInfo, PC, Offset, OpSize, InstSize, TagType, TagBuf);
                }
            };
    }

    protected LLVMOpInfoCallback() {
        super(DESCRIPTOR);
    }

    LLVMOpInfoCallback(long functionPointer) {
        super(functionPointer);
    }

}