/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.shaderc;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke shaderc_include_result_release_fn} */
@FunctionalInterface
@NativeType("shaderc_include_result_release_fn")
public interface ShadercIncludeResultReleaseI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        ShadercIncludeResultReleaseI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            ffi_type_void,
            ffi_type_pointer, ffi_type_pointer
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        invoke(
            memGetAddress(memGetAddress(args)),
            memGetAddress(memGetAddress(args + POINTER_SIZE))
        );
    }

    /** {@code void (* shaderc_include_result_release_fn) (void * user_data, shaderc_include_result * include_result)} */
    void invoke(@NativeType("void *") long user_data, @NativeType("shaderc_include_result *") long include_result);

}