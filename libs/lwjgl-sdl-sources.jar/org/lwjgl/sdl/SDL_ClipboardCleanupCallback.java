/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.sdl;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke SDL_ClipboardCleanupCallback} */
public abstract class SDL_ClipboardCleanupCallback extends Callback implements SDL_ClipboardCleanupCallbackI {

    /**
     * Creates a {@code SDL_ClipboardCleanupCallback} instance from the specified function pointer.
     *
     * @return the new {@code SDL_ClipboardCleanupCallback}
     */
    public static SDL_ClipboardCleanupCallback create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable SDL_ClipboardCleanupCallback createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code SDL_ClipboardCleanupCallback} instance that delegates to the specified {@code SDL_ClipboardCleanupCallbackI} instance. */
    public static SDL_ClipboardCleanupCallback create(SDL_ClipboardCleanupCallbackI instance) { return create(instance, instance.address()); }

    private static SDL_ClipboardCleanupCallback create(SDL_ClipboardCleanupCallbackI instance, long functionPointer) {
        return instance instanceof SDL_ClipboardCleanupCallback
            ? (SDL_ClipboardCleanupCallback)instance
            : new SDL_ClipboardCleanupCallback(functionPointer) {
                @Override public void invoke(long userdata) {
                    instance.invoke(userdata);
                }
            };
    }

    protected SDL_ClipboardCleanupCallback() {
        super(DESCRIPTOR);
    }

    SDL_ClipboardCleanupCallback(long functionPointer) {
        super(functionPointer);
    }

}