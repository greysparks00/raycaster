/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.lmdb;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * <pre>{@code
 * struct MDB_val {
 *     size_t mv_size;
 *     void * mv_data;
 * }}</pre>
 */
@NativeType("struct MDB_val")
public class MDBVal extends Struct<MDBVal> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        MV_SIZE,
        MV_DATA;

    static {
        Layout layout = __struct(
            __member(POINTER_SIZE),
            __member(POINTER_SIZE)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        MV_SIZE = layout.offsetof(0);
        MV_DATA = layout.offsetof(1);
    }

    protected MDBVal(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected MDBVal create(long address, @Nullable ByteBuffer container) {
        return new MDBVal(address, container);
    }

    /**
     * Creates a {@code MDBVal} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public MDBVal(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return the value of the {@code mv_size} field. */
    @NativeType("size_t")
    public long mv_size() { return nmv_size(address()); }
    /** @return a {@link ByteBuffer} view of the data pointed to by the {@code mv_data} field. */
    @NativeType("void *")
    public @Nullable ByteBuffer mv_data() { return nmv_data(address()); }

    /** Sets the specified value to the {@code mv_size} field. */
    public MDBVal mv_size(@NativeType("size_t") long value) { nmv_size(address(), value); return this; }
    /** Sets the address of the specified {@link ByteBuffer} to the {@code mv_data} field. */
    public MDBVal mv_data(@Nullable @NativeType("void *") ByteBuffer value) { nmv_data(address(), value); return this; }

    /** Initializes this struct with the specified values. */
    public MDBVal set(
        long mv_size,
        @Nullable ByteBuffer mv_data
    ) {
        mv_size(mv_size);
        mv_data(mv_data);

        return this;
    }

    /**
     * Copies the specified struct data to this struct.
     *
     * @param src the source struct
     *
     * @return this struct
     */
    public MDBVal set(MDBVal src) {
        memCopy(src.address(), address(), SIZEOF);
        return this;
    }

    // -----------------------------------

    /** Returns a new {@code MDBVal} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static MDBVal malloc() {
        return new MDBVal(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code MDBVal} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static MDBVal calloc() {
        return new MDBVal(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code MDBVal} instance allocated with {@link BufferUtils}. */
    public static MDBVal create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new MDBVal(memAddress(container), container);
    }

    /** Returns a new {@code MDBVal} instance for the specified memory address. */
    public static MDBVal create(long address) {
        return new MDBVal(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable MDBVal createSafe(long address) {
        return address == NULL ? null : new MDBVal(address, null);
    }

    /**
     * Returns a new {@link MDBVal.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static MDBVal.Buffer malloc(int capacity) {
        return new Buffer(nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link MDBVal.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static MDBVal.Buffer calloc(int capacity) {
        return new Buffer(nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link MDBVal.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static MDBVal.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return new Buffer(memAddress(container), container, -1, 0, capacity, capacity);
    }

    /**
     * Create a {@link MDBVal.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static MDBVal.Buffer create(long address, int capacity) {
        return new Buffer(address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static MDBVal.@Nullable Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : new Buffer(address, capacity);
    }

    /**
     * Returns a new {@code MDBVal} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static MDBVal malloc(MemoryStack stack) {
        return new MDBVal(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code MDBVal} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static MDBVal calloc(MemoryStack stack) {
        return new MDBVal(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    /**
     * Returns a new {@link MDBVal.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static MDBVal.Buffer malloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link MDBVal.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static MDBVal.Buffer calloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #mv_size}. */
    public static long nmv_size(long struct) { return memGetAddress(struct + MDBVal.MV_SIZE); }
    /** Unsafe version of {@link #mv_data() mv_data}. */
    public static @Nullable ByteBuffer nmv_data(long struct) { return memByteBufferSafe(memGetAddress(struct + MDBVal.MV_DATA), (int)nmv_size(struct)); }

    /** Sets the specified value to the {@code mv_size} field of the specified {@code struct}. */
    public static void nmv_size(long struct, long value) { memPutAddress(struct + MDBVal.MV_SIZE, value); }
    /** Unsafe version of {@link #mv_data(ByteBuffer) mv_data}. */
    public static void nmv_data(long struct, @Nullable ByteBuffer value) { memPutAddress(struct + MDBVal.MV_DATA, memAddressSafe(value)); if (value != null) { nmv_size(struct, value.remaining()); } }

    // -----------------------------------

    /** An array of {@link MDBVal} structs. */
    public static class Buffer extends StructBuffer<MDBVal, Buffer> implements NativeResource {

        private static final MDBVal ELEMENT_FACTORY = MDBVal.create(-1L);

        /**
         * Creates a new {@code MDBVal.Buffer} instance backed by the specified container.
         *
         * <p>Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link MDBVal#SIZEOF}, and its mark will be undefined.</p>
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected Buffer create(long address, @Nullable ByteBuffer container, int mark, int position, int limit, int capacity) {
            return new Buffer(address, container, mark, position, limit, capacity);
        }

        @Override
        protected MDBVal getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** @return the value of the {@code mv_size} field. */
        @NativeType("size_t")
        public long mv_size() { return MDBVal.nmv_size(address()); }
        /** @return a {@link ByteBuffer} view of the data pointed to by the {@code mv_data} field. */
        @NativeType("void *")
        public @Nullable ByteBuffer mv_data() { return MDBVal.nmv_data(address()); }

        /** Sets the specified value to the {@code mv_size} field. */
        public MDBVal.Buffer mv_size(@NativeType("size_t") long value) { MDBVal.nmv_size(address(), value); return this; }
        /** Sets the address of the specified {@link ByteBuffer} to the {@code mv_data} field. */
        public MDBVal.Buffer mv_data(@Nullable @NativeType("void *") ByteBuffer value) { MDBVal.nmv_data(address(), value); return this; }

    }

}