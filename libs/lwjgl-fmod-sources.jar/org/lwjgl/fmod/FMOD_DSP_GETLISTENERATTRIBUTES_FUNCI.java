/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.fmod;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke FMOD_DSP_GETLISTENERATTRIBUTES_FUNC} */
@FunctionalInterface
@NativeType("FMOD_DSP_GETLISTENERATTRIBUTES_FUNC")
public interface FMOD_DSP_GETLISTENERATTRIBUTES_FUNCI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        FMOD_DSP_GETLISTENERATTRIBUTES_FUNCI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            apiStdcall(),
            ffi_type_uint32,
            ffi_type_pointer, ffi_type_pointer, ffi_type_pointer
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        int __result = invoke(
            memGetAddress(memGetAddress(args)),
            memGetAddress(memGetAddress(args + POINTER_SIZE)),
            memGetAddress(memGetAddress(args + 2 * POINTER_SIZE))
        );
        apiClosureRet(ret, __result);
    }

    /** {@code FMOD_RESULT (* FMOD_DSP_GETLISTENERATTRIBUTES_FUNC) (struct FMOD_DSP_STATE * dsp_state, int * numlisteners, FMOD_3D_ATTRIBUTES * attributes)} */
    @NativeType("FMOD_RESULT") int invoke(@NativeType("struct FMOD_DSP_STATE *") long dsp_state, @NativeType("int *") long numlisteners, @NativeType("FMOD_3D_ATTRIBUTES *") long attributes);

}