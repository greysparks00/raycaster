/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.fmod;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke FMOD_SOUND_NONBLOCK_CALLBACK} */
@FunctionalInterface
@NativeType("FMOD_SOUND_NONBLOCK_CALLBACK")
public interface FMOD_SOUND_NONBLOCK_CALLBACKI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        FMOD_SOUND_NONBLOCK_CALLBACKI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            apiStdcall(),
            ffi_type_uint32,
            ffi_type_pointer, ffi_type_uint32
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        int __result = invoke(
            memGetAddress(memGetAddress(args)),
            memGetInt(memGetAddress(args + POINTER_SIZE))
        );
        apiClosureRet(ret, __result);
    }

    /** {@code FMOD_RESULT (* FMOD_SOUND_NONBLOCK_CALLBACK) (FMOD_SOUND * sound, FMOD_RESULT result)} */
    @NativeType("FMOD_RESULT") int invoke(@NativeType("FMOD_SOUND *") long sound, @NativeType("FMOD_RESULT") int result);

}