/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.fmod;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke FMOD_DEBUG_CALLBACK} */
public abstract class FMOD_DEBUG_CALLBACK extends Callback implements FMOD_DEBUG_CALLBACKI {

    /**
     * Creates a {@code FMOD_DEBUG_CALLBACK} instance from the specified function pointer.
     *
     * @return the new {@code FMOD_DEBUG_CALLBACK}
     */
    public static FMOD_DEBUG_CALLBACK create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable FMOD_DEBUG_CALLBACK createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code FMOD_DEBUG_CALLBACK} instance that delegates to the specified {@code FMOD_DEBUG_CALLBACKI} instance. */
    public static FMOD_DEBUG_CALLBACK create(FMOD_DEBUG_CALLBACKI instance) { return create(instance, instance.address()); }

    private static FMOD_DEBUG_CALLBACK create(FMOD_DEBUG_CALLBACKI instance, long functionPointer) {
        return instance instanceof FMOD_DEBUG_CALLBACK
            ? (FMOD_DEBUG_CALLBACK)instance
            : new FMOD_DEBUG_CALLBACK(functionPointer) {
                @Override public int invoke(int flags, long file, int line, long func, long message) {
                    return instance.invoke(flags, file, line, func, message);
                }
            };
    }

    protected FMOD_DEBUG_CALLBACK() {
        super(DESCRIPTOR);
    }

    FMOD_DEBUG_CALLBACK(long functionPointer) {
        super(functionPointer);
    }

}