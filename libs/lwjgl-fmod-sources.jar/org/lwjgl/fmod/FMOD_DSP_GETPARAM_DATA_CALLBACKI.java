/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.fmod;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke FMOD_DSP_GETPARAM_DATA_CALLBACK} */
@FunctionalInterface
@NativeType("FMOD_DSP_GETPARAM_DATA_CALLBACK")
public interface FMOD_DSP_GETPARAM_DATA_CALLBACKI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        FMOD_DSP_GETPARAM_DATA_CALLBACKI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            apiStdcall(),
            ffi_type_uint32,
            ffi_type_pointer, ffi_type_sint32, ffi_type_pointer, ffi_type_pointer, ffi_type_pointer
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        int __result = invoke(
            memGetAddress(memGetAddress(args)),
            memGetInt(memGetAddress(args + POINTER_SIZE)),
            memGetAddress(memGetAddress(args + 2 * POINTER_SIZE)),
            memGetAddress(memGetAddress(args + 3 * POINTER_SIZE)),
            memGetAddress(memGetAddress(args + 4 * POINTER_SIZE))
        );
        apiClosureRet(ret, __result);
    }

    /** {@code FMOD_RESULT (* FMOD_DSP_GETPARAM_DATA_CALLBACK) (struct FMOD_DSP_STATE * dsp_state, int index, void ** data, unsigned int * length, char * valuestr)} */
    @NativeType("FMOD_RESULT") int invoke(@NativeType("struct FMOD_DSP_STATE *") long dsp_state, int index, @NativeType("void **") long data, @NativeType("unsigned int *") long length, @NativeType("char *") long valuestr);

}