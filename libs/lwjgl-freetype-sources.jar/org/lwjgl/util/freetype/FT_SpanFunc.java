/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.freetype;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke FT_SpanFunc} */
public abstract class FT_SpanFunc extends Callback implements FT_SpanFuncI {

    /**
     * Creates a {@code FT_SpanFunc} instance from the specified function pointer.
     *
     * @return the new {@code FT_SpanFunc}
     */
    public static FT_SpanFunc create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable FT_SpanFunc createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code FT_SpanFunc} instance that delegates to the specified {@code FT_SpanFuncI} instance. */
    public static FT_SpanFunc create(FT_SpanFuncI instance) { return create(instance, instance.address()); }

    private static FT_SpanFunc create(FT_SpanFuncI instance, long functionPointer) {
        return instance instanceof FT_SpanFunc
            ? (FT_SpanFunc)instance
            : new FT_SpanFunc(functionPointer) {
                @Override public void invoke(int y, int count, long spans, long user) {
                    instance.invoke(y, count, spans, user);
                }
            };
    }

    protected FT_SpanFunc() {
        super(DESCRIPTOR);
    }

    FT_SpanFunc(long functionPointer) {
        super(functionPointer);
    }

}