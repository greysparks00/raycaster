/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.freetype;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke FTC_Face_Requester} */
public abstract class FTC_Face_Requester extends Callback implements FTC_Face_RequesterI {

    /**
     * Creates a {@code FTC_Face_Requester} instance from the specified function pointer.
     *
     * @return the new {@code FTC_Face_Requester}
     */
    public static FTC_Face_Requester create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable FTC_Face_Requester createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code FTC_Face_Requester} instance that delegates to the specified {@code FTC_Face_RequesterI} instance. */
    public static FTC_Face_Requester create(FTC_Face_RequesterI instance) { return create(instance, instance.address()); }

    private static FTC_Face_Requester create(FTC_Face_RequesterI instance, long functionPointer) {
        return instance instanceof FTC_Face_Requester
            ? (FTC_Face_Requester)instance
            : new FTC_Face_Requester(functionPointer) {
                @Override public int invoke(long face_id, long library, long req_data, long aface) {
                    return instance.invoke(face_id, library, req_data, aface);
                }
            };
    }

    protected FTC_Face_Requester() {
        super(DESCRIPTOR);
    }

    FTC_Face_Requester(long functionPointer) {
        super(functionPointer);
    }

}