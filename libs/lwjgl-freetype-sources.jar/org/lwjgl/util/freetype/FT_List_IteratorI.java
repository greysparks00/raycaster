/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.freetype;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke FT_List_Iterator} */
@FunctionalInterface
@NativeType("FT_List_Iterator")
public interface FT_List_IteratorI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        FT_List_IteratorI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            ffi_type_sint32,
            ffi_type_pointer, ffi_type_pointer
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        int __result = invoke(
            memGetAddress(memGetAddress(args)),
            memGetAddress(memGetAddress(args + POINTER_SIZE))
        );
        apiClosureRet(ret, __result);
    }

    /** {@code FT_Error (* FT_List_Iterator) (FT_ListNode node, void * user)} */
    @NativeType("FT_Error") int invoke(@NativeType("FT_ListNode") long node, @NativeType("void *") long user);

}