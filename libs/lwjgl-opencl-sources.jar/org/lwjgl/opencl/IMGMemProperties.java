/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.opencl;

public final class IMGMemProperties {

    public static final long CL_MEM_ALLOC_FLAGS_IMG = 0x40D7L;

    public static final long CL_MEM_ALLOC_RELAX_REQUIREMENTS_IMG = 1L << 0;

    private IMGMemProperties() {}

}