/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.opencl;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * <pre>{@code
 * struct cl_mem_ext_host_ptr {
 *     cl_uint allocation_type;
 *     cl_uint host_cache_policy;
 * }}</pre>
 */
@NativeType("struct cl_mem_ext_host_ptr")
public class CLMemEXTHostPtr extends Struct<CLMemEXTHostPtr> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        ALLOCATION_TYPE,
        HOST_CACHE_POLICY;

    static {
        Layout layout = __struct(
            __member(4),
            __member(4)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        ALLOCATION_TYPE = layout.offsetof(0);
        HOST_CACHE_POLICY = layout.offsetof(1);
    }

    protected CLMemEXTHostPtr(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected CLMemEXTHostPtr create(long address, @Nullable ByteBuffer container) {
        return new CLMemEXTHostPtr(address, container);
    }

    /**
     * Creates a {@code CLMemEXTHostPtr} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public CLMemEXTHostPtr(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return the value of the {@code allocation_type} field. */
    @NativeType("cl_uint")
    public int allocation_type() { return nallocation_type(address()); }
    /** @return the value of the {@code host_cache_policy} field. */
    @NativeType("cl_uint")
    public int host_cache_policy() { return nhost_cache_policy(address()); }

    /** Sets the specified value to the {@code allocation_type} field. */
    public CLMemEXTHostPtr allocation_type(@NativeType("cl_uint") int value) { nallocation_type(address(), value); return this; }
    /** Sets the specified value to the {@code host_cache_policy} field. */
    public CLMemEXTHostPtr host_cache_policy(@NativeType("cl_uint") int value) { nhost_cache_policy(address(), value); return this; }

    /** Initializes this struct with the specified values. */
    public CLMemEXTHostPtr set(
        int allocation_type,
        int host_cache_policy
    ) {
        allocation_type(allocation_type);
        host_cache_policy(host_cache_policy);

        return this;
    }

    /**
     * Copies the specified struct data to this struct.
     *
     * @param src the source struct
     *
     * @return this struct
     */
    public CLMemEXTHostPtr set(CLMemEXTHostPtr src) {
        memCopy(src.address(), address(), SIZEOF);
        return this;
    }

    // -----------------------------------

    /** Returns a new {@code CLMemEXTHostPtr} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static CLMemEXTHostPtr malloc() {
        return new CLMemEXTHostPtr(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code CLMemEXTHostPtr} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static CLMemEXTHostPtr calloc() {
        return new CLMemEXTHostPtr(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code CLMemEXTHostPtr} instance allocated with {@link BufferUtils}. */
    public static CLMemEXTHostPtr create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new CLMemEXTHostPtr(memAddress(container), container);
    }

    /** Returns a new {@code CLMemEXTHostPtr} instance for the specified memory address. */
    public static CLMemEXTHostPtr create(long address) {
        return new CLMemEXTHostPtr(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable CLMemEXTHostPtr createSafe(long address) {
        return address == NULL ? null : new CLMemEXTHostPtr(address, null);
    }

    /**
     * Returns a new {@link CLMemEXTHostPtr.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static CLMemEXTHostPtr.Buffer malloc(int capacity) {
        return new Buffer(nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link CLMemEXTHostPtr.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static CLMemEXTHostPtr.Buffer calloc(int capacity) {
        return new Buffer(nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link CLMemEXTHostPtr.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static CLMemEXTHostPtr.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return new Buffer(memAddress(container), container, -1, 0, capacity, capacity);
    }

    /**
     * Create a {@link CLMemEXTHostPtr.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static CLMemEXTHostPtr.Buffer create(long address, int capacity) {
        return new Buffer(address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static CLMemEXTHostPtr.@Nullable Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : new Buffer(address, capacity);
    }

    /**
     * Returns a new {@code CLMemEXTHostPtr} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static CLMemEXTHostPtr malloc(MemoryStack stack) {
        return new CLMemEXTHostPtr(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code CLMemEXTHostPtr} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static CLMemEXTHostPtr calloc(MemoryStack stack) {
        return new CLMemEXTHostPtr(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    /**
     * Returns a new {@link CLMemEXTHostPtr.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static CLMemEXTHostPtr.Buffer malloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link CLMemEXTHostPtr.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static CLMemEXTHostPtr.Buffer calloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #allocation_type}. */
    public static int nallocation_type(long struct) { return memGetInt(struct + CLMemEXTHostPtr.ALLOCATION_TYPE); }
    /** Unsafe version of {@link #host_cache_policy}. */
    public static int nhost_cache_policy(long struct) { return memGetInt(struct + CLMemEXTHostPtr.HOST_CACHE_POLICY); }

    /** Unsafe version of {@link #allocation_type(int) allocation_type}. */
    public static void nallocation_type(long struct, int value) { memPutInt(struct + CLMemEXTHostPtr.ALLOCATION_TYPE, value); }
    /** Unsafe version of {@link #host_cache_policy(int) host_cache_policy}. */
    public static void nhost_cache_policy(long struct, int value) { memPutInt(struct + CLMemEXTHostPtr.HOST_CACHE_POLICY, value); }

    // -----------------------------------

    /** An array of {@link CLMemEXTHostPtr} structs. */
    public static class Buffer extends StructBuffer<CLMemEXTHostPtr, Buffer> implements NativeResource {

        private static final CLMemEXTHostPtr ELEMENT_FACTORY = CLMemEXTHostPtr.create(-1L);

        /**
         * Creates a new {@code CLMemEXTHostPtr.Buffer} instance backed by the specified container.
         *
         * <p>Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link CLMemEXTHostPtr#SIZEOF}, and its mark will be undefined.</p>
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected Buffer create(long address, @Nullable ByteBuffer container, int mark, int position, int limit, int capacity) {
            return new Buffer(address, container, mark, position, limit, capacity);
        }

        @Override
        protected CLMemEXTHostPtr getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** @return the value of the {@code allocation_type} field. */
        @NativeType("cl_uint")
        public int allocation_type() { return CLMemEXTHostPtr.nallocation_type(address()); }
        /** @return the value of the {@code host_cache_policy} field. */
        @NativeType("cl_uint")
        public int host_cache_policy() { return CLMemEXTHostPtr.nhost_cache_policy(address()); }

        /** Sets the specified value to the {@code allocation_type} field. */
        public CLMemEXTHostPtr.Buffer allocation_type(@NativeType("cl_uint") int value) { CLMemEXTHostPtr.nallocation_type(address(), value); return this; }
        /** Sets the specified value to the {@code host_cache_policy} field. */
        public CLMemEXTHostPtr.Buffer host_cache_policy(@NativeType("cl_uint") int value) { CLMemEXTHostPtr.nhost_cache_policy(address(), value); return this; }

    }

}