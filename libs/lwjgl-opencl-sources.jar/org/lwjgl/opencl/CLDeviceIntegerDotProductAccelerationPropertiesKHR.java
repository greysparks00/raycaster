/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.opencl;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * <pre>{@code
 * struct cl_device_integer_dot_product_acceleration_properties_khr {
 *     cl_bool signed_accelerated;
 *     cl_bool unsigned_accelerated;
 *     cl_bool mixed_signedness_accelerated;
 *     cl_bool accumulating_saturating_signed_accelerated;
 *     cl_bool accumulating_saturating_unsigned_accelerated;
 *     cl_bool accumulating_saturating_mixed_signedness_accelerated;
 * }}</pre>
 */
@NativeType("struct cl_device_integer_dot_product_acceleration_properties_khr")
public class CLDeviceIntegerDotProductAccelerationPropertiesKHR extends Struct<CLDeviceIntegerDotProductAccelerationPropertiesKHR> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        SIGNED_ACCELERATED,
        UNSIGNED_ACCELERATED,
        MIXED_SIGNEDNESS_ACCELERATED,
        ACCUMULATING_SATURATING_SIGNED_ACCELERATED,
        ACCUMULATING_SATURATING_UNSIGNED_ACCELERATED,
        ACCUMULATING_SATURATING_MIXED_SIGNEDNESS_ACCELERATED;

    static {
        Layout layout = __struct(
            __member(4),
            __member(4),
            __member(4),
            __member(4),
            __member(4),
            __member(4)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        SIGNED_ACCELERATED = layout.offsetof(0);
        UNSIGNED_ACCELERATED = layout.offsetof(1);
        MIXED_SIGNEDNESS_ACCELERATED = layout.offsetof(2);
        ACCUMULATING_SATURATING_SIGNED_ACCELERATED = layout.offsetof(3);
        ACCUMULATING_SATURATING_UNSIGNED_ACCELERATED = layout.offsetof(4);
        ACCUMULATING_SATURATING_MIXED_SIGNEDNESS_ACCELERATED = layout.offsetof(5);
    }

    protected CLDeviceIntegerDotProductAccelerationPropertiesKHR(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected CLDeviceIntegerDotProductAccelerationPropertiesKHR create(long address, @Nullable ByteBuffer container) {
        return new CLDeviceIntegerDotProductAccelerationPropertiesKHR(address, container);
    }

    /**
     * Creates a {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public CLDeviceIntegerDotProductAccelerationPropertiesKHR(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return the value of the {@code signed_accelerated} field. */
    @NativeType("cl_bool")
    public boolean signed_accelerated() { return nsigned_accelerated(address()) != 0; }
    /** @return the value of the {@code unsigned_accelerated} field. */
    @NativeType("cl_bool")
    public boolean unsigned_accelerated() { return nunsigned_accelerated(address()) != 0; }
    /** @return the value of the {@code mixed_signedness_accelerated} field. */
    @NativeType("cl_bool")
    public boolean mixed_signedness_accelerated() { return nmixed_signedness_accelerated(address()) != 0; }
    /** @return the value of the {@code accumulating_saturating_signed_accelerated} field. */
    @NativeType("cl_bool")
    public boolean accumulating_saturating_signed_accelerated() { return naccumulating_saturating_signed_accelerated(address()) != 0; }
    /** @return the value of the {@code accumulating_saturating_unsigned_accelerated} field. */
    @NativeType("cl_bool")
    public boolean accumulating_saturating_unsigned_accelerated() { return naccumulating_saturating_unsigned_accelerated(address()) != 0; }
    /** @return the value of the {@code accumulating_saturating_mixed_signedness_accelerated} field. */
    @NativeType("cl_bool")
    public boolean accumulating_saturating_mixed_signedness_accelerated() { return naccumulating_saturating_mixed_signedness_accelerated(address()) != 0; }

    // -----------------------------------

    /** Returns a new {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR malloc() {
        return new CLDeviceIntegerDotProductAccelerationPropertiesKHR(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR calloc() {
        return new CLDeviceIntegerDotProductAccelerationPropertiesKHR(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR} instance allocated with {@link BufferUtils}. */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new CLDeviceIntegerDotProductAccelerationPropertiesKHR(memAddress(container), container);
    }

    /** Returns a new {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR} instance for the specified memory address. */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR create(long address) {
        return new CLDeviceIntegerDotProductAccelerationPropertiesKHR(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable CLDeviceIntegerDotProductAccelerationPropertiesKHR createSafe(long address) {
        return address == NULL ? null : new CLDeviceIntegerDotProductAccelerationPropertiesKHR(address, null);
    }

    /**
     * Returns a new {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer malloc(int capacity) {
        return new Buffer(nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer calloc(int capacity) {
        return new Buffer(nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return new Buffer(memAddress(container), container, -1, 0, capacity, capacity);
    }

    /**
     * Create a {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer create(long address, int capacity) {
        return new Buffer(address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR.@Nullable Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : new Buffer(address, capacity);
    }

    /**
     * Returns a new {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR malloc(MemoryStack stack) {
        return new CLDeviceIntegerDotProductAccelerationPropertiesKHR(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR calloc(MemoryStack stack) {
        return new CLDeviceIntegerDotProductAccelerationPropertiesKHR(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    /**
     * Returns a new {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer malloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer calloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #signed_accelerated}. */
    public static int nsigned_accelerated(long struct) { return memGetInt(struct + CLDeviceIntegerDotProductAccelerationPropertiesKHR.SIGNED_ACCELERATED); }
    /** Unsafe version of {@link #unsigned_accelerated}. */
    public static int nunsigned_accelerated(long struct) { return memGetInt(struct + CLDeviceIntegerDotProductAccelerationPropertiesKHR.UNSIGNED_ACCELERATED); }
    /** Unsafe version of {@link #mixed_signedness_accelerated}. */
    public static int nmixed_signedness_accelerated(long struct) { return memGetInt(struct + CLDeviceIntegerDotProductAccelerationPropertiesKHR.MIXED_SIGNEDNESS_ACCELERATED); }
    /** Unsafe version of {@link #accumulating_saturating_signed_accelerated}. */
    public static int naccumulating_saturating_signed_accelerated(long struct) { return memGetInt(struct + CLDeviceIntegerDotProductAccelerationPropertiesKHR.ACCUMULATING_SATURATING_SIGNED_ACCELERATED); }
    /** Unsafe version of {@link #accumulating_saturating_unsigned_accelerated}. */
    public static int naccumulating_saturating_unsigned_accelerated(long struct) { return memGetInt(struct + CLDeviceIntegerDotProductAccelerationPropertiesKHR.ACCUMULATING_SATURATING_UNSIGNED_ACCELERATED); }
    /** Unsafe version of {@link #accumulating_saturating_mixed_signedness_accelerated}. */
    public static int naccumulating_saturating_mixed_signedness_accelerated(long struct) { return memGetInt(struct + CLDeviceIntegerDotProductAccelerationPropertiesKHR.ACCUMULATING_SATURATING_MIXED_SIGNEDNESS_ACCELERATED); }

    // -----------------------------------

    /** An array of {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR} structs. */
    public static class Buffer extends StructBuffer<CLDeviceIntegerDotProductAccelerationPropertiesKHR, Buffer> implements NativeResource {

        private static final CLDeviceIntegerDotProductAccelerationPropertiesKHR ELEMENT_FACTORY = CLDeviceIntegerDotProductAccelerationPropertiesKHR.create(-1L);

        /**
         * Creates a new {@code CLDeviceIntegerDotProductAccelerationPropertiesKHR.Buffer} instance backed by the specified container.
         *
         * <p>Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link CLDeviceIntegerDotProductAccelerationPropertiesKHR#SIZEOF}, and its mark will be undefined.</p>
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected Buffer create(long address, @Nullable ByteBuffer container, int mark, int position, int limit, int capacity) {
            return new Buffer(address, container, mark, position, limit, capacity);
        }

        @Override
        protected CLDeviceIntegerDotProductAccelerationPropertiesKHR getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** @return the value of the {@code signed_accelerated} field. */
        @NativeType("cl_bool")
        public boolean signed_accelerated() { return CLDeviceIntegerDotProductAccelerationPropertiesKHR.nsigned_accelerated(address()) != 0; }
        /** @return the value of the {@code unsigned_accelerated} field. */
        @NativeType("cl_bool")
        public boolean unsigned_accelerated() { return CLDeviceIntegerDotProductAccelerationPropertiesKHR.nunsigned_accelerated(address()) != 0; }
        /** @return the value of the {@code mixed_signedness_accelerated} field. */
        @NativeType("cl_bool")
        public boolean mixed_signedness_accelerated() { return CLDeviceIntegerDotProductAccelerationPropertiesKHR.nmixed_signedness_accelerated(address()) != 0; }
        /** @return the value of the {@code accumulating_saturating_signed_accelerated} field. */
        @NativeType("cl_bool")
        public boolean accumulating_saturating_signed_accelerated() { return CLDeviceIntegerDotProductAccelerationPropertiesKHR.naccumulating_saturating_signed_accelerated(address()) != 0; }
        /** @return the value of the {@code accumulating_saturating_unsigned_accelerated} field. */
        @NativeType("cl_bool")
        public boolean accumulating_saturating_unsigned_accelerated() { return CLDeviceIntegerDotProductAccelerationPropertiesKHR.naccumulating_saturating_unsigned_accelerated(address()) != 0; }
        /** @return the value of the {@code accumulating_saturating_mixed_signedness_accelerated} field. */
        @NativeType("cl_bool")
        public boolean accumulating_saturating_mixed_signedness_accelerated() { return CLDeviceIntegerDotProductAccelerationPropertiesKHR.naccumulating_saturating_mixed_signedness_accelerated(address()) != 0; }

    }

}