/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openxr;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * <pre>{@code
 * struct XrForceFeedbackCurlApplyLocationMNDX {
 *     XrForceFeedbackCurlLocationMNDX location;
 *     float value;
 * }}</pre>
 */
public class XrForceFeedbackCurlApplyLocationMNDX extends Struct<XrForceFeedbackCurlApplyLocationMNDX> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        LOCATION,
        VALUE;

    static {
        Layout layout = __struct(
            __member(4),
            __member(4)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        LOCATION = layout.offsetof(0);
        VALUE = layout.offsetof(1);
    }

    protected XrForceFeedbackCurlApplyLocationMNDX(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected XrForceFeedbackCurlApplyLocationMNDX create(long address, @Nullable ByteBuffer container) {
        return new XrForceFeedbackCurlApplyLocationMNDX(address, container);
    }

    /**
     * Creates a {@code XrForceFeedbackCurlApplyLocationMNDX} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public XrForceFeedbackCurlApplyLocationMNDX(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return the value of the {@code location} field. */
    @NativeType("XrForceFeedbackCurlLocationMNDX")
    public int location() { return nlocation(address()); }
    /** @return the value of the {@code value} field. */
    public float value() { return nvalue(address()); }

    /** Sets the specified value to the {@code location} field. */
    public XrForceFeedbackCurlApplyLocationMNDX location(@NativeType("XrForceFeedbackCurlLocationMNDX") int value) { nlocation(address(), value); return this; }
    /** Sets the specified value to the {@code value} field. */
    public XrForceFeedbackCurlApplyLocationMNDX value(float value) { nvalue(address(), value); return this; }

    /** Initializes this struct with the specified values. */
    public XrForceFeedbackCurlApplyLocationMNDX set(
        int location,
        float value
    ) {
        location(location);
        value(value);

        return this;
    }

    /**
     * Copies the specified struct data to this struct.
     *
     * @param src the source struct
     *
     * @return this struct
     */
    public XrForceFeedbackCurlApplyLocationMNDX set(XrForceFeedbackCurlApplyLocationMNDX src) {
        memCopy(src.address(), address(), SIZEOF);
        return this;
    }

    // -----------------------------------

    /** Returns a new {@code XrForceFeedbackCurlApplyLocationMNDX} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static XrForceFeedbackCurlApplyLocationMNDX malloc() {
        return new XrForceFeedbackCurlApplyLocationMNDX(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code XrForceFeedbackCurlApplyLocationMNDX} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static XrForceFeedbackCurlApplyLocationMNDX calloc() {
        return new XrForceFeedbackCurlApplyLocationMNDX(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code XrForceFeedbackCurlApplyLocationMNDX} instance allocated with {@link BufferUtils}. */
    public static XrForceFeedbackCurlApplyLocationMNDX create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new XrForceFeedbackCurlApplyLocationMNDX(memAddress(container), container);
    }

    /** Returns a new {@code XrForceFeedbackCurlApplyLocationMNDX} instance for the specified memory address. */
    public static XrForceFeedbackCurlApplyLocationMNDX create(long address) {
        return new XrForceFeedbackCurlApplyLocationMNDX(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable XrForceFeedbackCurlApplyLocationMNDX createSafe(long address) {
        return address == NULL ? null : new XrForceFeedbackCurlApplyLocationMNDX(address, null);
    }

    /**
     * Returns a new {@link XrForceFeedbackCurlApplyLocationMNDX.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static XrForceFeedbackCurlApplyLocationMNDX.Buffer malloc(int capacity) {
        return new Buffer(nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link XrForceFeedbackCurlApplyLocationMNDX.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static XrForceFeedbackCurlApplyLocationMNDX.Buffer calloc(int capacity) {
        return new Buffer(nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link XrForceFeedbackCurlApplyLocationMNDX.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static XrForceFeedbackCurlApplyLocationMNDX.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return new Buffer(memAddress(container), container, -1, 0, capacity, capacity);
    }

    /**
     * Create a {@link XrForceFeedbackCurlApplyLocationMNDX.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static XrForceFeedbackCurlApplyLocationMNDX.Buffer create(long address, int capacity) {
        return new Buffer(address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static XrForceFeedbackCurlApplyLocationMNDX.@Nullable Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : new Buffer(address, capacity);
    }

    /**
     * Returns a new {@code XrForceFeedbackCurlApplyLocationMNDX} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static XrForceFeedbackCurlApplyLocationMNDX malloc(MemoryStack stack) {
        return new XrForceFeedbackCurlApplyLocationMNDX(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code XrForceFeedbackCurlApplyLocationMNDX} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static XrForceFeedbackCurlApplyLocationMNDX calloc(MemoryStack stack) {
        return new XrForceFeedbackCurlApplyLocationMNDX(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    /**
     * Returns a new {@link XrForceFeedbackCurlApplyLocationMNDX.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static XrForceFeedbackCurlApplyLocationMNDX.Buffer malloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link XrForceFeedbackCurlApplyLocationMNDX.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static XrForceFeedbackCurlApplyLocationMNDX.Buffer calloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #location}. */
    public static int nlocation(long struct) { return memGetInt(struct + XrForceFeedbackCurlApplyLocationMNDX.LOCATION); }
    /** Unsafe version of {@link #value}. */
    public static float nvalue(long struct) { return memGetFloat(struct + XrForceFeedbackCurlApplyLocationMNDX.VALUE); }

    /** Unsafe version of {@link #location(int) location}. */
    public static void nlocation(long struct, int value) { memPutInt(struct + XrForceFeedbackCurlApplyLocationMNDX.LOCATION, value); }
    /** Unsafe version of {@link #value(float) value}. */
    public static void nvalue(long struct, float value) { memPutFloat(struct + XrForceFeedbackCurlApplyLocationMNDX.VALUE, value); }

    // -----------------------------------

    /** An array of {@link XrForceFeedbackCurlApplyLocationMNDX} structs. */
    public static class Buffer extends StructBuffer<XrForceFeedbackCurlApplyLocationMNDX, Buffer> implements NativeResource {

        private static final XrForceFeedbackCurlApplyLocationMNDX ELEMENT_FACTORY = XrForceFeedbackCurlApplyLocationMNDX.create(-1L);

        /**
         * Creates a new {@code XrForceFeedbackCurlApplyLocationMNDX.Buffer} instance backed by the specified container.
         *
         * <p>Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link XrForceFeedbackCurlApplyLocationMNDX#SIZEOF}, and its mark will be undefined.</p>
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected Buffer create(long address, @Nullable ByteBuffer container, int mark, int position, int limit, int capacity) {
            return new Buffer(address, container, mark, position, limit, capacity);
        }

        @Override
        protected XrForceFeedbackCurlApplyLocationMNDX getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** @return the value of the {@code location} field. */
        @NativeType("XrForceFeedbackCurlLocationMNDX")
        public int location() { return XrForceFeedbackCurlApplyLocationMNDX.nlocation(address()); }
        /** @return the value of the {@code value} field. */
        public float value() { return XrForceFeedbackCurlApplyLocationMNDX.nvalue(address()); }

        /** Sets the specified value to the {@code location} field. */
        public XrForceFeedbackCurlApplyLocationMNDX.Buffer location(@NativeType("XrForceFeedbackCurlLocationMNDX") int value) { XrForceFeedbackCurlApplyLocationMNDX.nlocation(address(), value); return this; }
        /** Sets the specified value to the {@code value} field. */
        public XrForceFeedbackCurlApplyLocationMNDX.Buffer value(float value) { XrForceFeedbackCurlApplyLocationMNDX.nvalue(address(), value); return this; }

    }

}