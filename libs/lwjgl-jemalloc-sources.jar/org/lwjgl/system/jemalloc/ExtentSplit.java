/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.system.jemalloc;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke extent_split_t} */
public abstract class ExtentSplit extends Callback implements ExtentSplitI {

    /**
     * Creates a {@code ExtentSplit} instance from the specified function pointer.
     *
     * @return the new {@code ExtentSplit}
     */
    public static ExtentSplit create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable ExtentSplit createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code ExtentSplit} instance that delegates to the specified {@code ExtentSplitI} instance. */
    public static ExtentSplit create(ExtentSplitI instance) { return create(instance, instance.address()); }

    private static ExtentSplit create(ExtentSplitI instance, long functionPointer) {
        return instance instanceof ExtentSplit
            ? (ExtentSplit)instance
            : new ExtentSplit(functionPointer) {
                @Override public boolean invoke(long extent_hooks, long addr, long size, long size_a, long size_b, boolean committed, int arena_ind) {
                    return instance.invoke(extent_hooks, addr, size, size_a, size_b, committed, arena_ind);
                }
            };
    }

    protected ExtentSplit() {
        super(DESCRIPTOR);
    }

    ExtentSplit(long functionPointer) {
        super(functionPointer);
    }

}