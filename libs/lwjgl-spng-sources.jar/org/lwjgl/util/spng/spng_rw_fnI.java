/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.spng;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke spng_rw_fn *} */
@FunctionalInterface
@NativeType("spng_rw_fn *")
public interface spng_rw_fnI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        spng_rw_fnI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            ffi_type_void,
            ffi_type_pointer, ffi_type_pointer, ffi_type_pointer, ffi_type_pointer
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        invoke(
            memGetAddress(memGetAddress(args)),
            memGetAddress(memGetAddress(args + POINTER_SIZE)),
            memGetAddress(memGetAddress(args + 2 * POINTER_SIZE)),
            memGetAddress(memGetAddress(args + 3 * POINTER_SIZE))
        );
    }

    /** {@code void (* spng_rw_fn *) (spng_ctx * ctx, void * user, void * dest, size_t length)} */
    void invoke(@NativeType("spng_ctx *") long ctx, @NativeType("void *") long user, @NativeType("void *") long dest, @NativeType("size_t") long length);

}