/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.opus;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke op_close_func} */
public abstract class OPCloseFunc extends Callback implements OPCloseFuncI {

    /**
     * Creates a {@code OPCloseFunc} instance from the specified function pointer.
     *
     * @return the new {@code OPCloseFunc}
     */
    public static OPCloseFunc create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable OPCloseFunc createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code OPCloseFunc} instance that delegates to the specified {@code OPCloseFuncI} instance. */
    public static OPCloseFunc create(OPCloseFuncI instance) { return create(instance, instance.address()); }

    private static OPCloseFunc create(OPCloseFuncI instance, long functionPointer) {
        return instance instanceof OPCloseFunc
            ? (OPCloseFunc)instance
            : new OPCloseFunc(functionPointer) {
                @Override public int invoke(long _stream) {
                    return instance.invoke(_stream);
                }
            };
    }

    protected OPCloseFunc() {
        super(DESCRIPTOR);
    }

    OPCloseFunc(long functionPointer) {
        super(functionPointer);
    }

}