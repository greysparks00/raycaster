/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.xxhash;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.Checks.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

import static org.lwjgl.util.xxhash.XXHash.*;

/**
 * <pre><code>
 * struct XXH3_state_t {
 *     XXH64_hash_t acc[8];
 *     unsigned char customSecret[XXH3_SECRET_DEFAULT_SIZE];
 *     char[64 - (XXH3_SECRET_DEFAULT_SIZE &amp; 63)];
 *     unsigned char buffer[256];
 *     XXH32_hash_t bufferedSize;
 *     XXH32_hash_t useSeed;
 *     size_t nbStripesSoFar;
 *     XXH64_hash_t totalLen;
 *     size_t nbStripesPerBlock;
 *     size_t secretLimit;
 *     XXH64_hash_t seed;
 *     XXH64_hash_t reserved64;
 *     unsigned char const * extSecret;
 * }</code></pre>
 */
@NativeType("struct XXH3_state_t")
public class XXH3State extends Struct<XXH3State> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        ACC,
        CUSTOMSECRET,
        BUFFER,
        BUFFEREDSIZE,
        USESEED,
        NBSTRIPESSOFAR,
        TOTALLEN,
        NBSTRIPESPERBLOCK,
        SECRETLIMIT,
        SEED,
        RESERVED64,
        EXTSECRET;

    static {
        Layout layout = __struct(
            DEFAULT_PACK_ALIGNMENT, 64,
            __array(8, 8),
            __array(1, XXH3_SECRET_DEFAULT_SIZE),
            __padding(64 - (XXH3_SECRET_DEFAULT_SIZE & 63), (XXH3_SECRET_DEFAULT_SIZE & 63) != 0),
            __array(1, 256),
            __member(4),
            __member(4),
            __member(POINTER_SIZE),
            __member(8),
            __member(POINTER_SIZE),
            __member(POINTER_SIZE),
            __member(8),
            __member(8),
            __member(POINTER_SIZE)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        ACC = layout.offsetof(0);
        CUSTOMSECRET = layout.offsetof(1);
        BUFFER = layout.offsetof(3);
        BUFFEREDSIZE = layout.offsetof(4);
        USESEED = layout.offsetof(5);
        NBSTRIPESSOFAR = layout.offsetof(6);
        TOTALLEN = layout.offsetof(7);
        NBSTRIPESPERBLOCK = layout.offsetof(8);
        SECRETLIMIT = layout.offsetof(9);
        SEED = layout.offsetof(10);
        RESERVED64 = layout.offsetof(11);
        EXTSECRET = layout.offsetof(12);
    }

    protected XXH3State(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected XXH3State create(long address, @Nullable ByteBuffer container) {
        return new XXH3State(address, container);
    }

    /**
     * Creates a {@code XXH3State} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public XXH3State(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return a {@link LongBuffer} view of the {@code acc} field. */
    @NativeType("XXH64_hash_t[8]")
    public LongBuffer acc() { return nacc(address()); }
    /** @return the value at the specified index of the {@code acc} field. */
    @NativeType("XXH64_hash_t")
    public long acc(int index) { return nacc(address(), index); }
    /** @return a {@link ByteBuffer} view of the {@code customSecret} field. */
    @NativeType("unsigned char[XXH3_SECRET_DEFAULT_SIZE]")
    public ByteBuffer customSecret() { return ncustomSecret(address()); }
    /** @return the value at the specified index of the {@code customSecret} field. */
    @NativeType("unsigned char")
    public byte customSecret(int index) { return ncustomSecret(address(), index); }
    /** @return a {@link ByteBuffer} view of the {@code buffer} field. */
    @NativeType("unsigned char[256]")
    public ByteBuffer buffer() { return nbuffer(address()); }
    /** @return the value at the specified index of the {@code buffer} field. */
    @NativeType("unsigned char")
    public byte buffer(int index) { return nbuffer(address(), index); }
    /** @return the value of the {@code bufferedSize} field. */
    @NativeType("XXH32_hash_t")
    public int bufferedSize() { return nbufferedSize(address()); }
    /** @return the value of the {@code useSeed} field. */
    @NativeType("XXH32_hash_t")
    public int useSeed() { return nuseSeed(address()); }
    /** @return the value of the {@code nbStripesSoFar} field. */
    @NativeType("size_t")
    public long nbStripesSoFar() { return nnbStripesSoFar(address()); }
    /** @return the value of the {@code totalLen} field. */
    @NativeType("XXH64_hash_t")
    public long totalLen() { return ntotalLen(address()); }
    /** @return the value of the {@code nbStripesPerBlock} field. */
    @NativeType("size_t")
    public long nbStripesPerBlock() { return nnbStripesPerBlock(address()); }
    /** @return the value of the {@code secretLimit} field. */
    @NativeType("size_t")
    public long secretLimit() { return nsecretLimit(address()); }
    /** @return the value of the {@code seed} field. */
    @NativeType("XXH64_hash_t")
    public long seed() { return nseed(address()); }
    /** @return the value of the {@code reserved64} field. */
    @NativeType("XXH64_hash_t")
    public long reserved64() { return nreserved64(address()); }
    /** @return a {@link ByteBuffer} view of the data pointed to by the {@code extSecret} field. */
    @NativeType("unsigned char const *")
    public ByteBuffer extSecret(int capacity) { return nextSecret(address(), capacity); }

    // -----------------------------------

    /** Returns a new {@code XXH3State} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static XXH3State malloc() {
        return new XXH3State(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code XXH3State} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static XXH3State calloc() {
        return new XXH3State(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code XXH3State} instance allocated with {@link BufferUtils}. */
    public static XXH3State create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new XXH3State(memAddress(container), container);
    }

    /** Returns a new {@code XXH3State} instance for the specified memory address. */
    public static XXH3State create(long address) {
        return new XXH3State(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable XXH3State createSafe(long address) {
        return address == NULL ? null : new XXH3State(address, null);
    }

    /**
     * Returns a new {@link XXH3State.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static XXH3State.Buffer malloc(int capacity) {
        return new Buffer(nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link XXH3State.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static XXH3State.Buffer calloc(int capacity) {
        return new Buffer(nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link XXH3State.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static XXH3State.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return new Buffer(memAddress(container), container, -1, 0, capacity, capacity);
    }

    /**
     * Create a {@link XXH3State.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static XXH3State.Buffer create(long address, int capacity) {
        return new Buffer(address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static XXH3State.@Nullable Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : new Buffer(address, capacity);
    }

    /**
     * Returns a new {@code XXH3State} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static XXH3State malloc(MemoryStack stack) {
        return new XXH3State(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code XXH3State} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static XXH3State calloc(MemoryStack stack) {
        return new XXH3State(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    /**
     * Returns a new {@link XXH3State.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static XXH3State.Buffer malloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link XXH3State.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static XXH3State.Buffer calloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #acc}. */
    public static LongBuffer nacc(long struct) { return memLongBuffer(struct + XXH3State.ACC, 8); }
    /** Unsafe version of {@link #acc(int) acc}. */
    public static long nacc(long struct, int index) {
        return memGetLong(struct + XXH3State.ACC + check(index, 8) * 8);
    }
    /** Unsafe version of {@link #customSecret}. */
    public static ByteBuffer ncustomSecret(long struct) { return memByteBuffer(struct + XXH3State.CUSTOMSECRET, XXH3_SECRET_DEFAULT_SIZE); }
    /** Unsafe version of {@link #customSecret(int) customSecret}. */
    public static byte ncustomSecret(long struct, int index) {
        return memGetByte(struct + XXH3State.CUSTOMSECRET + check(index, XXH3_SECRET_DEFAULT_SIZE) * 1);
    }
    /** Unsafe version of {@link #buffer}. */
    public static ByteBuffer nbuffer(long struct) { return memByteBuffer(struct + XXH3State.BUFFER, 256); }
    /** Unsafe version of {@link #buffer(int) buffer}. */
    public static byte nbuffer(long struct, int index) {
        return memGetByte(struct + XXH3State.BUFFER + check(index, 256) * 1);
    }
    /** Unsafe version of {@link #bufferedSize}. */
    public static int nbufferedSize(long struct) { return memGetInt(struct + XXH3State.BUFFEREDSIZE); }
    /** Unsafe version of {@link #useSeed}. */
    public static int nuseSeed(long struct) { return memGetInt(struct + XXH3State.USESEED); }
    /** Unsafe version of {@link #nbStripesSoFar}. */
    public static long nnbStripesSoFar(long struct) { return memGetAddress(struct + XXH3State.NBSTRIPESSOFAR); }
    /** Unsafe version of {@link #totalLen}. */
    public static long ntotalLen(long struct) { return memGetLong(struct + XXH3State.TOTALLEN); }
    /** Unsafe version of {@link #nbStripesPerBlock}. */
    public static long nnbStripesPerBlock(long struct) { return memGetAddress(struct + XXH3State.NBSTRIPESPERBLOCK); }
    /** Unsafe version of {@link #secretLimit}. */
    public static long nsecretLimit(long struct) { return memGetAddress(struct + XXH3State.SECRETLIMIT); }
    /** Unsafe version of {@link #seed}. */
    public static long nseed(long struct) { return memGetLong(struct + XXH3State.SEED); }
    /** Unsafe version of {@link #reserved64}. */
    public static long nreserved64(long struct) { return memGetLong(struct + XXH3State.RESERVED64); }
    /** Unsafe version of {@link #extSecret(int) extSecret}. */
    public static ByteBuffer nextSecret(long struct, int capacity) { return memByteBuffer(memGetAddress(struct + XXH3State.EXTSECRET), capacity); }

    // -----------------------------------

    /** An array of {@link XXH3State} structs. */
    public static class Buffer extends StructBuffer<XXH3State, Buffer> implements NativeResource {

        private static final XXH3State ELEMENT_FACTORY = XXH3State.create(-1L);

        /**
         * Creates a new {@code XXH3State.Buffer} instance backed by the specified container.
         *
         * <p>Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link XXH3State#SIZEOF}, and its mark will be undefined.</p>
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected Buffer create(long address, @Nullable ByteBuffer container, int mark, int position, int limit, int capacity) {
            return new Buffer(address, container, mark, position, limit, capacity);
        }

        @Override
        protected XXH3State getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** @return a {@link LongBuffer} view of the {@code acc} field. */
        @NativeType("XXH64_hash_t[8]")
        public LongBuffer acc() { return XXH3State.nacc(address()); }
        /** @return the value at the specified index of the {@code acc} field. */
        @NativeType("XXH64_hash_t")
        public long acc(int index) { return XXH3State.nacc(address(), index); }
        /** @return a {@link ByteBuffer} view of the {@code customSecret} field. */
        @NativeType("unsigned char[XXH3_SECRET_DEFAULT_SIZE]")
        public ByteBuffer customSecret() { return XXH3State.ncustomSecret(address()); }
        /** @return the value at the specified index of the {@code customSecret} field. */
        @NativeType("unsigned char")
        public byte customSecret(int index) { return XXH3State.ncustomSecret(address(), index); }
        /** @return a {@link ByteBuffer} view of the {@code buffer} field. */
        @NativeType("unsigned char[256]")
        public ByteBuffer buffer() { return XXH3State.nbuffer(address()); }
        /** @return the value at the specified index of the {@code buffer} field. */
        @NativeType("unsigned char")
        public byte buffer(int index) { return XXH3State.nbuffer(address(), index); }
        /** @return the value of the {@code bufferedSize} field. */
        @NativeType("XXH32_hash_t")
        public int bufferedSize() { return XXH3State.nbufferedSize(address()); }
        /** @return the value of the {@code useSeed} field. */
        @NativeType("XXH32_hash_t")
        public int useSeed() { return XXH3State.nuseSeed(address()); }
        /** @return the value of the {@code nbStripesSoFar} field. */
        @NativeType("size_t")
        public long nbStripesSoFar() { return XXH3State.nnbStripesSoFar(address()); }
        /** @return the value of the {@code totalLen} field. */
        @NativeType("XXH64_hash_t")
        public long totalLen() { return XXH3State.ntotalLen(address()); }
        /** @return the value of the {@code nbStripesPerBlock} field. */
        @NativeType("size_t")
        public long nbStripesPerBlock() { return XXH3State.nnbStripesPerBlock(address()); }
        /** @return the value of the {@code secretLimit} field. */
        @NativeType("size_t")
        public long secretLimit() { return XXH3State.nsecretLimit(address()); }
        /** @return the value of the {@code seed} field. */
        @NativeType("XXH64_hash_t")
        public long seed() { return XXH3State.nseed(address()); }
        /** @return the value of the {@code reserved64} field. */
        @NativeType("XXH64_hash_t")
        public long reserved64() { return XXH3State.nreserved64(address()); }
        /** @return a {@link ByteBuffer} view of the data pointed to by the {@code extSecret} field. */
        @NativeType("unsigned char const *")
        public ByteBuffer extSecret(int capacity) { return XXH3State.nextSecret(address(), capacity); }

    }

}