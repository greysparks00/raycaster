/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 */
package org.lwjgl.system;

import org.jspecify.annotations.*;

import java.util.function.*;
import java.util.regex.*;

import static org.lwjgl.system.APIUtil.*;

/** The platforms supported by LWJGL. */
public enum Platform {

    FREEBSD("FreeBSD", "freebsd") {
        private final Pattern SO = Pattern.compile("(?:^|/)lib\\w+[.]so(?:[.]\\d+)*$");

        @Override
        String mapLibraryName(String name) {
            if (SO.matcher(name).find()) {
                return name;
            }

            return System.mapLibraryName(name);
        }
    },
    LINUX("Linux", "linux") {
        private final Pattern SO = Pattern.compile("(?:^|/)lib\\w+[.]so(?:[.]\\d+)*$");

        @Override
        String mapLibraryName(String name) {
            if (SO.matcher(name).find()) {
                return name;
            }

            return System.mapLibraryName(name);
        }
    },
    // TODO: Rename to MACOS in LWJGL 4
    MACOSX("macOS", "macos") {
        private final Pattern DYLIB = Pattern.compile("(?:^|/)lib\\w+(?:[.]\\d+)*[.]dylib$");

        @Override
        String mapLibraryName(String name) {
            if (DYLIB.matcher(name).find()) {
                return name;
            }

            return System.mapLibraryName(name);
        }
    },
    WINDOWS("Windows", "windows") {
        @Override
        String mapLibraryName(String name) {
            if (name.endsWith(".dll")) {
                return name;
            }

            return System.mapLibraryName(name);
        }
    };

    /** The architectures supported by LWJGL. */
    public enum Architecture {
        X64(true),
        X86(false),
        ARM64(true),
        ARM32(false),
        PPC64LE(true),
        RISCV64(true);

        static final Architecture current;

        final boolean is64Bit;

        static {
            String  osArch  = System.getProperty("os.arch");
            boolean is64Bit = osArch.contains("64") || osArch.startsWith("armv8");

            if (osArch.startsWith("arm") || osArch.startsWith("aarch")) {
                current = is64Bit ? Architecture.ARM64 : Architecture.ARM32;
            } else if (osArch.startsWith("ppc")) {
                if (!"ppc64le".equals(osArch)) {
                    throw new UnsupportedOperationException("Only PowerPC 64 LE is supported.");
                }
                current = Architecture.PPC64LE;
            } else if (osArch.startsWith("riscv")) {
                if (!"riscv64".equals(osArch)) {
                    throw new UnsupportedOperationException("Only RISC-V 64 is supported.");
                }
                current = Architecture.RISCV64;
            } else {
                current = is64Bit ? Architecture.X64 : Architecture.X86;
            }
        }

        Architecture(boolean is64Bit) {
            this.is64Bit = is64Bit;
        }

        public boolean is32Bit() {
            return !is64Bit;
        }

        public boolean is64Bit() {
            return is64Bit;
        }
    }

    private static final int JAVA_VERSION;

    private static final Platform current;

    private static final Function<String, String> bundledLibraryNameMapper;
    private static final Function<String, String> bundledLibraryPathMapper;

    static {
        String javaVersion = System.getProperty("java.version");
        Matcher matcher = Pattern
            .compile("^([1-9][0-9]*)(?:(?:\\.0)*\\.[1-9][0-9]*)*(?:-[a-zA-Z0-9]+)?")
            .matcher(javaVersion);

        if (!matcher.find()) {
            if (javaVersion.startsWith("1.")) {
                if (!javaVersion.startsWith("1.8.")) {
                    throw new UnsupportedOperationException("JDK 8 or newer is required.");
                }
            }
            throw new IllegalStateException("Failed to parse java.version: " + javaVersion);
        }

        JAVA_VERSION = Math.max(8, Integer.parseInt(matcher.group(1)));

        String osName = System.getProperty("os.name");
        if (osName.startsWith("Windows")) {
            current = WINDOWS;
        } else if (osName.startsWith("FreeBSD")) {
            current = FREEBSD;
        } else if (osName.startsWith("Linux") || osName.startsWith("SunOS") || osName.startsWith("Unix")) {
            current = LINUX;
        } else if (osName.startsWith("Mac OS X") || osName.startsWith("Darwin")) {
            current = MACOSX;
        } else {
            throw new LinkageError("Unknown platform: " + osName);
        }

        bundledLibraryNameMapper = getMapper(
            Configuration.BUNDLED_LIBRARY_NAME_MAPPER.get("default"),
            name -> name,
            name -> Architecture.current.is64Bit ? name : name + "32"
        );
        bundledLibraryPathMapper = getMapper(
            Configuration.BUNDLED_LIBRARY_PATH_MAPPER.get("default"),
            name -> current.nativePath + "/" + Architecture.current.name().toLowerCase() + "/" + name,
            name -> name.substring(name.lastIndexOf('/'))
        );
    }

    private final String name;
    private final String nativePath;

    Platform(String name, String nativePath) {
        this.name = name;
        this.nativePath = nativePath;
    }

    /** Returns the platform name. */
    public String getName() {
        return name;
    }

    abstract String mapLibraryName(String name);

    public static int getJavaVersion() {
        return JAVA_VERSION;
    }

    /** Returns the platform on which the library is running. */
    public static Platform get() {
        return current;
    }

    /** Returns the architecture on which the library is running. */
    public static Architecture getArchitecture() {
        return Architecture.current;
    }

    public static String mapLibraryNameBundled(String name) {
        return bundledLibraryNameMapper.apply(name);
    }

    static String mapLibraryPathBundled(String name) {
        return bundledLibraryPathMapper.apply(name);
    }

    @SuppressWarnings("unchecked")
    private static Function<String, String> getMapper(
        @Nullable Object mapper,
        Function<String, String> defaultMapper,
        Function<String, String> legacyMapper
    ) {
        if (mapper == null || "default".equals(mapper)) {
            return defaultMapper;
        }

        if ("legacy".equals(mapper)) {
            return legacyMapper;
        }

        if (mapper instanceof Function) {
            return (Function<String, String>)mapper;
        }

        String className = mapper.toString();
        try {
            return (Function<String, String>)Class
                .forName(className)
                .getConstructor()
                .newInstance();
        } catch (Throwable t) {
            if (Checks.DEBUG) {
                t.printStackTrace(DEBUG_STREAM);
            }
            apiLog(String.format("Warning: Failed to instantiate bundled library mapper: %s. Using the default.", className));
            return defaultMapper;
        }
    }

}