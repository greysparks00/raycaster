/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.vma;

import org.lwjgl.system.*;

import java.lang.invoke.*;

import static org.lwjgl.system.APIUtil.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.libffi.LibFFI.*;

/** Callback function: {@link #invoke PFN_vmaCheckDefragmentationBreakFunction} */
@FunctionalInterface
@NativeType("PFN_vmaCheckDefragmentationBreakFunction")
public interface VmaCheckDefragmentationBreakFunctionI extends CallbackI {

    Callback.Descriptor DESCRIPTOR = new Callback.Descriptor(
        VmaCheckDefragmentationBreakFunctionI.class,
        MethodHandles.lookup(),
        apiCreateCIF(
            ffi_type_uint32,
            ffi_type_pointer
        )
    );

    @Override
    default Callback.Descriptor getDescriptor() { return DESCRIPTOR; }

    @Override
    default void callback(long ret, long args) {
        int __result = invoke(
            memGetAddress(memGetAddress(args))
        );
        apiClosureRet(ret, __result);
    }

    /** {@code VkBool32 (* PFN_vmaCheckDefragmentationBreakFunction) (void * pUserData)} */
    @NativeType("VkBool32") int invoke(@NativeType("void *") long pUserData);

}