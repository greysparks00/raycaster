/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.vulkan;

public final class EXTImageTilingControl {

    public static final int VK_EXT_IMAGE_TILING_CONTROL_SPEC_VERSION = 1;

    public static final String VK_EXT_IMAGE_TILING_CONTROL_EXTENSION_NAME = "VK_EXT_image_tiling_control";

    public static final int
        VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_IMAGE_TILING_CONTROL_FEATURES_EXT = 1000687000,
        VK_STRUCTURE_TYPE_IMAGE_TILING_CONTROL_CREATE_INFO_EXT              = 1000687001;

    public static final int
        VK_IMAGE_TILING_CONTROL_DEFAULT_EXT         = 0,
        VK_IMAGE_TILING_CONTROL_MIN_SIZE_EXT        = 1,
        VK_IMAGE_TILING_CONTROL_MAX_PERFORMANCE_EXT = 2;

    private EXTImageTilingControl() {}

}